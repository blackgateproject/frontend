import { issueCredential, resolveDID } from "@spruceid/didkit-wasm";
import { Buffer } from "buffer";
import { ethers, SigningKey } from "ethers";
import { Loader2 } from "lucide-react";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";

const LoginPage = () => {
  const [walletExists, setWalletExists] = useState(
    !!localStorage.getItem("encryptedWallet")
  );
  const [walletPassword, setWalletPassword] = useState("");
  const [isLoadingWallet, setIsLoadingWallet] = useState(false);
  const [wallet, setWallet] = useState(null);
  const [account, setAccount] = useState("");
  const [signedVC, setSignedVC] = useState(null);
  const [challenge, setChallenge] = useState(null);
  const [isClaimsModalOpen, setIsClaimsModalOpen] = useState(false);
  const [selectedClaims, setSelectedClaims] = useState([]);
  const [currentStep, setCurrentStep] = useState("");
  const navigate = useNavigate();

  const createNewWallet = async () => {
    const newWallet = ethers.Wallet.createRandom();
    const encryptedWallet = await newWallet.encrypt(walletPassword);
    localStorage.setItem("encryptedWallet", encryptedWallet);
    setWalletExists(true);
    setWallet(newWallet);
    setAccount(newWallet.address);
    console.log("New wallet created:", newWallet);
    const did = "did:ethr:" + newWallet.address;
    console.log("DID:", did);
    await getDIDandVC(did);
    await signChallenge();
  };

  const getDIDandVC = async (did) => {
    if (!wallet) {
      console.error("Wallet is not loaded.");
      return;
      return;
    }
    setCurrentStep("Generating DID Document...");
    const didDoc = await resolveDID(String(did), "{}");
    console.log("DID Document:", didDoc);
    setCurrentStep("Generating Verifiable Credential...");
    const credential = JSON.stringify({
      "@context": ["https://www.w3.org/2018/credentials/v1"],
      type: ["VerifiableCredential"],
      issuer: did,
      credentialSubject: { id: "did:example:123", claims: selectedClaims },
      issuanceDate: new Date().toISOString(),
    });

    console.log("Credential:", credential);
    const proof_options = JSON.stringify({
      proofPurpose: "assertionMethod",
      verificationMethod: `${did}#controller`,
    });

    console.log("Proof Options:", proof_options);

    let newUncompPubKey = SigningKey.computePublicKey(wallet.privateKey, false);
    if (newUncompPubKey instanceof Uint8Array) {
      newUncompPubKey = hexlify(newUncompPubKey);
    }

    const rawPubKey = newUncompPubKey.startsWith("0x04")
      ? newUncompPubKey.slice(4)
      : newUncompPubKey;
    const newRawPubKey = "0x" + rawPubKey;

    const xPubKey = Buffer.from(newRawPubKey.slice(2, 66), "hex")
      .toString("base64")
      .replace(/=+$/, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_");
    const yPubKey = Buffer.from(newRawPubKey.slice(66), "hex")
      .toString("base64")
      .replace(/=+$/, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_");

    const jwk = JSON.stringify({
      kty: "EC",
      crv: "secp256k1",
      d: Buffer.from(wallet.privateKey.slice(2), "hex")
        .toString("base64")
        .replace(/=+$/, "")
        .replace(/\+/g, "-")
        .replace(/\//g, "_"),
      x: xPubKey,
      y: yPubKey,
    });

    console.log("JWK:", jwk);
    const signed_vc = await issueCredential(credential, proof_options, jwk);
    console.log("Signed VC:", signed_vc);
    setSignedVC(signed_vc);

    // Send DID, DIDDoc, and VC to Connector
    const response = await fetch("http://127.0.0.1:8000/connector/verify", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({ did, didDoc, signed_vc }),
    });

    if (response.ok) {
      const data = await response.json();
      console.log("Challenge received:", data.challenge);
      setChallenge(data.challenge);
    } else {
      console.error("Failed to verify with connector");
    }
  };

  const signChallenge = async () => {
    if (!wallet || !challenge) {
      console.error("Wallet or challenge is not available.");
      return;
    }

    const signature = await wallet.signMessage(challenge);
    console.log("Signed Challenge:", signature);

    // Send signed challenge back to Connector
    const response = await fetch("http://127.0.0.1:8000/connector/finalize", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({ signature }),
    });

    if (response.ok) {
      const data = await response.json();
      console.log("Registration finalized:", data);
      navigate("/dashboard");
    } else {
      console.error("Failed to finalize registration");
    }
  };

  const loadWallet = async () => {
    const encryptedWallet = localStorage.getItem("encryptedWallet");
    if (encryptedWallet) {
      try {
        setIsLoadingWallet(true);
        const loadedWallet = await ethers.Wallet.fromEncryptedJson(
          encryptedWallet,
          walletPassword
        );
        setWallet(loadedWallet);
        setAccount(loadedWallet.address);
        console.log("Wallet loaded:", loadedWallet);
        const did = "did:ethr:" + loadedWallet.address;
        console.log("DID:", did);
        setWallet(loadedWallet); // Ensure wallet is set before calling getDIDandVC
        await getDIDandVC(did);
        await signChallenge();
      } catch (err) {
        console.error("Error in loadWallet:", err);
        if (err.message.includes("key expansion failed")) {
          alert(
            "Failed to load wallet. Please check your password and try again."
          );
        } else {
          alert("Failed to load wallet.");
        }
      } finally {
        setIsLoadingWallet(false);
        setIsPasswordModalOpen(false);
      }
    } else {
      alert("No wallet found. Please create a new wallet.");
    }
  };

  const handleOpenPasswordModal = () => {
    setIsPasswordModalOpen(true);
    setIsLoadingWallet(false);
    setTimeout(() => {
      document.getElementById("wallet-password-input").focus();
    }, 100);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (walletExists) {
      loadWallet();
    } else {
      createNewWallet();
    }
  };

  const handleClaimsSubmit = (e) => {
    e.preventDefault();
    setIsClaimsModalOpen(false);
    setCurrentStep("Generating DID...");
    const did = "did:ethr:" + wallet.address;
    console.log("DID:", did);
    getDIDandVC(did);
    signChallenge();
  };

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-r from-purple-600 to-pink-600">
      <div className="bg-base-100 p-10 rounded-2xl shadow-xl w-96 overflow-hidden">
        <img src={logo} alt="logo" className="w-24 mx-auto mb-4" />
        <h2 className="text-center text-3xl font-bold mb-6 text-primary">
          {walletExists ? "BLACKGATE" : "Welcome to BLACKGATE"}
        </h2>

        <div className="mt-4 text-center">
          <button
            onClick={handleOpenPasswordModal}
            className={`btn w-full ${
              walletExists
                ? "bg-primary/75 hover:bg-primary"
                : "bg-green-500 hover:bg-green-600"
            } text-base-100 rounded-2xl mt-4`}
            disabled={signedVC}
          >
            {walletExists ? "Unlock and Connect Wallet" : "Create New Wallet"}
          </button>
        </div>
        {currentStep && (
          <div className="mt-4 text-center text-white">
            <p>{currentStep}</p>
          </div>
        )}
      </div>
      <dialog id="password-modal" className="modal" open={isPasswordModalOpen}>
        <form className="modal-box" onSubmit={handleSubmit}>
          <h3 className="font-bold text-lg">
            {walletExists ? "Enter Wallet Password" : "Set Wallet Password"}
          </h3>
          <input
            id="wallet-password-input"
            type="password"
            value={walletPassword}
            onChange={(e) => setWalletPassword(e.target.value)}
            className="input input-bordered w-full mt-4"
            placeholder={
              walletExists
                ? "Enter your wallet password"
                : "Set a password for your new wallet"
            }
          />
          <div className="modal-action">
            <button
              type="button"
              className="btn"
              onClick={() => {
                setIsPasswordModalOpen(false);
                setWalletPassword("");
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={isLoadingWallet}
            >
              {isLoadingWallet ? (
                <Loader2 className="animate-spin" />
              ) : (
                "Submit"
              )}
            </button>
          </div>
        </form>
      </dialog>
      <dialog id="claims-modal" className="modal" open={isClaimsModalOpen}>
        <form className="modal-box" onSubmit={handleClaimsSubmit}>
          <h3 className="font-bold text-lg">Select Claims</h3>
          <div className="mt-4">
            <label className="block">
              <input
                type="checkbox"
                value="claim1"
                onChange={(e) => {
                  const value = e.target.value;
                  setSelectedClaims((prev) =>
                    prev.includes(value)
                      ? prev.filter((claim) => claim !== value)
                      : [...prev, value]
                  );
                }}
              />
              Claim 1
            </label>
            <label className="block">
              <input
                type="checkbox"
                value="claim2"
                onChange={(e) => {
                  const value = e.target.value;
                  setSelectedClaims((prev) =>
                    prev.includes(value)
                      ? prev.filter((claim) => claim !== value)
                      : [...prev, value]
                  );
                }}
              />
              Claim 2
            </label>
            <label className="block">
              <input
                type="checkbox"
                value="claim3"
                onChange={(e) => {
                  const value = e.target.value;
                  setSelectedClaims((prev) =>
                    prev.includes(value)
                      ? prev.filter((claim) => claim !== value)
                      : [...prev, value]
                  );
                }}
              />
              Claim 3
            </label>
          </div>
          <div className="modal-action">
            <button
              type="button"
              className="btn"
              onClick={() => setIsClaimsModalOpen(false)}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </form>
      </dialog>
    </div>
  );
};

export default LoginPage;
